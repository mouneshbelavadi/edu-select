"""
KEA UGCET 2025 Seat Matrix  ->  one neat Excel file
Page: https://cetonline.karnataka.gov.in/viewmaps/SeatMatrix.aspx

Page structure (from your --inspect output):
    ddlProfCode  = Professional Course  (Architecture, Medical, Dental ... 23 types)
    ddlColleges  = KEA college list (fills after a Professional Course is chosen)
    ddlCourses   = courses/branches of that college (fills after a college is chosen)
    a#view       = the "View" link (it is a link, not a button)

TWO STAGES
  Stage 1 (default, fast):  MAP
      Professional Course -> every college -> every course that college offers.
      This is the "which college offers which course" list. Needs no View click.
  Stage 2 (optional, --seats):  SEAT MATRIX
      Clicks View for every college+course and saves the seat table.
      This is slow (thousands of clicks), so do Stage 1 first.

SETUP (once, Windows):
    python -m pip install playwright pandas openpyxl lxml
    python -m playwright install chromium

RUN:
    python kea_seat_matrix.py                       -> lists the 23 course types
    python kea_seat_matrix.py --profs A --limit 3   -> quick test (Architecture, 3 colleges)
    python kea_seat_matrix.py --all                 -> full map of everything  (recommended)
    python kea_seat_matrix.py --all --seats         -> map + seat tables (very slow)

Safe to stop and re-run: finished colleges are cached in ./kea_cache.
Please keep --delay at 1.5 or more (government server; its robots.txt asks bots
to stay away). Use for personal research and run the full job once.
"""

import argparse
import json
import re
import time
from io import StringIO
from pathlib import Path

import pandas as pd
from playwright.sync_api import sync_playwright

URL = "https://cetonline.karnataka.gov.in/viewmaps/SeatMatrix.aspx"
PROF, COLL, CRS, VIEW = "#ddlProfCode", "#ddlColleges", "#ddlCourses", "#view"
CACHE = Path("kea_cache")
OUT = "KEA_UGCET_2025_Complete.xlsx"


# ------------------------------------------------------------- page helpers
def safe(t):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", str(t)).strip("_")[:60]


def get_opts(page, sel):
    return page.evaluate(
        """(s) => [...document.querySelector(s).options]
                 .map(o => ({value: o.value, text: o.text.trim()}))""", sel)


def real(opts):
    return [o for o in opts if o["value"] not in ("", "-1") and "--" not in o["text"]]


def settle(page, delay):
    try:
        page.wait_for_load_state("networkidle", timeout=20000)
    except Exception:
        pass
    time.sleep(delay)


def pick(page, sel, value, delay):
    """Select an option; ASP.NET reloads the page, so retry if it was busy."""
    for _ in range(4):
        try:
            page.select_option(sel, value=value)
            break
        except Exception:
            time.sleep(1.5)
    settle(page, delay)


def wait_opts(page, sel, timeout=25):
    end = time.time() + timeout
    while time.time() < end:
        try:
            o = real(get_opts(page, sel))
            if o:
                return o
        except Exception:
            pass
        time.sleep(0.6)
    return []


def current(page, sel):
    try:
        return page.evaluate("(s) => document.querySelector(s).value", sel)
    except Exception:
        return None


def open_fresh(page, prof, delay, college=None):
    """Load page, choose professional course (and college if given)."""
    page.goto(URL, wait_until="networkidle")
    pick(page, PROF, prof, delay)
    colleges = wait_opts(page, COLL)
    courses = []
    if college is not None:
        pick(page, COLL, college, delay)
        courses = wait_opts(page, CRS)
    return colleges, courses


# ------------------------------------------------------------- stage 1: map
def build_map(page, prof_code, prof_name, args):
    cache_f = CACHE / f"map_{prof_code}.json"
    done = json.loads(cache_f.read_text(encoding="utf-8")) if cache_f.exists() else {}

    colleges, _ = open_fresh(page, prof_code, args.delay)
    if args.limit:
        colleges = colleges[: args.limit]
    print(f"\n[{prof_code}] {prof_name}: {len(colleges)} colleges")

    for n, col in enumerate(colleges, 1):
        v = col["value"]
        if v in done:
            print(f"  {n}/{len(colleges)} {col['text'][:50]} (cached)")
            continue
        try:
            if current(page, PROF) != prof_code:
                open_fresh(page, prof_code, args.delay)
            pick(page, COLL, v, args.delay)
            courses = wait_opts(page, CRS)
            done[v] = {"college_text": col["text"], "courses": courses}
            cache_f.write_text(json.dumps(done, ensure_ascii=False), encoding="utf-8")
            print(f"  {n}/{len(colleges)} {col['text'][:50]} -> {len(courses)} courses")
        except Exception as e:
            print(f"  {n}/{len(colleges)} ERROR {str(e)[:80]}")
            open_fresh(page, prof_code, args.delay)

    rows = []
    for v, d in done.items():
        text = d["college_text"]
        code = text.split()[0]
        rest = text[len(code):].strip()
        name, _, address = rest.partition(",")
        if not d["courses"]:
            rows.append(dict(prof_code=prof_code, prof_name=prof_name, college_value=v,
                             college_code=code, college_name=name.strip(), address=address.strip(),
                             course_value="", course=""))
        for c in d["courses"]:
            rows.append(dict(prof_code=prof_code, prof_name=prof_name, college_value=v,
                             college_code=code, college_name=name.strip(), address=address.strip(),
                             course_value=c["value"], course=c["text"]))
    return rows


# ------------------------------------------------------------- stage 2: seats
def scrape_tables(pg):
    try:
        tables = pd.read_html(StringIO(pg.content()))
    except ValueError:
        return []
    out = []
    for t in tables:
        t = t.dropna(how="all").dropna(axis=1, how="all")
        if t.shape[0] >= 1 and t.shape[1] >= 2:
            t.columns = [" ".join(map(str, c)).strip() if isinstance(c, tuple) else str(c).strip()
                         for c in t.columns]
            out.append(t)
    return out


def build_seats(page, ctx, map_rows, args):
    seats, errors = [], []
    first_saved = False
    todo = [r for r in map_rows if r["course_value"]]
    print(f"\nSeat tables: {len(todo)} college+course combinations")
    for n, r in enumerate(todo, 1):
        key = CACHE / f"seat_{r['prof_code']}_{safe(r['college_code'])}_{safe(r['course_value'])}.json"
        if key.exists():
            seats.extend(json.loads(key.read_text(encoding="utf-8")))
            continue
        try:
            if current(page, PROF) != r["prof_code"] or current(page, COLL) != r["college_value"]:
                open_fresh(page, r["prof_code"], args.delay, r["college_value"])
            pick(page, CRS, r["course_value"], args.delay)

            before = set(ctx.pages)
            page.locator(VIEW).click()
            time.sleep(2.5)
            new = [p for p in ctx.pages if p not in before]
            target = new[0] if new else page
            settle(target, args.delay)

            if not first_saved:
                (CACHE / "_first_view_result.html").write_text(target.content(), encoding="utf-8")
                print("  (saved _first_view_result.html - send it to me if tables look wrong)")
                first_saved = True

            rows = []
            for t in scrape_tables(target):
                for c, val in (("Course", r["course"]), ("College Name", r["college_name"]),
                               ("KEA College Code", r["college_code"]),
                               ("Professional Course", r["prof_name"])):
                    t.insert(0, c, val)
                rows.extend(t.to_dict("records"))
            key.write_text(json.dumps(rows, ensure_ascii=False), encoding="utf-8")
            seats.extend(rows)
            if new:
                target.close()
            print(f"  {n}/{len(todo)} {r['college_code']} {r['course'][:30]}: {len(rows)} rows")
        except Exception as e:
            errors.append(dict(prof=r["prof_name"], college=r["college_code"],
                               course=r["course"], error=str(e)[:200]))
            print(f"  {n}/{len(todo)} ERROR {str(e)[:70]}")
            for p in ctx.pages[1:]:
                p.close()
    return seats, errors


# ------------------------------------------------------------- excel
def style(xw):
    from openpyxl.styles import Alignment, Font, PatternFill
    fill = PatternFill("solid", fgColor="1F3864")
    for ws in xw.book.worksheets:
        for c in ws[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = fill
            c.alignment = Alignment(wrap_text=True, vertical="center")
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for col in ws.columns:
            w = max(len(str(c.value or "")) for c in col[:300]) + 2
            ws.column_dimensions[col[0].column_letter].width = min(max(w, 8), 60)


def write_excel(map_rows, seats, errors, prof_list):
    if not map_rows:
        print("Nothing collected.")
        return
    m = pd.DataFrame(map_rows).rename(columns={
        "prof_code": "Prof Code", "prof_name": "Professional Course",
        "college_code": "KEA College Code", "college_name": "College Name",
        "address": "Address / City", "course": "Course Offered"}).drop(
        columns=["college_value", "course_value"])
    m = m.drop_duplicates().sort_values(["Prof Code", "KEA College Code", "Course Offered"])

    colleges = (m.groupby(["Prof Code", "Professional Course", "KEA College Code",
                           "College Name", "Address / City"])["Course Offered"]
                .agg(lambda s: len([x for x in s if x]))
                .rename("No. of Courses").reset_index())
    summary = (colleges.groupby(["Prof Code", "Professional Course"])
               .agg(Colleges=("KEA College Code", "nunique"),
                    Courses=("No. of Courses", "sum")).reset_index())
    master = pd.DataFrame(prof_list).rename(columns={"value": "Prof Code", "text": "Professional Course"})

    # one row per college, with the courses joined (easy to read in Excel)
    joined = (m[m["Course Offered"] != ""]
              .groupby(["Prof Code", "Professional Course", "KEA College Code", "College Name"])
              ["Course Offered"].agg(lambda s: " | ".join(sorted(set(s)))).reset_index())

    with pd.ExcelWriter(OUT, engine="openpyxl") as xw:
        # first tab = the full detail (every college + every course name)
        m.to_excel(xw, sheet_name="College-Course Map", index=False)
        joined.to_excel(xw, sheet_name="College - Courses (joined)", index=False)
        colleges.to_excel(xw, sheet_name="Colleges", index=False)
        master.to_excel(xw, sheet_name="Course Types", index=False)
        summary.to_excel(xw, sheet_name="Summary", index=False)
        for code, part in m.groupby("Prof Code"):
            nm = part["Professional Course"].iloc[0]
            part.to_excel(xw, sheet_name=f"{code}_{safe(nm)}"[:31], index=False)
        if seats:
            pd.DataFrame(seats).to_excel(xw, sheet_name="Seat Matrix", index=False)
        if errors:
            pd.DataFrame(errors).to_excel(xw, sheet_name="Errors", index=False)
        style(xw)
    print(f"\nSaved -> {OUT}  ({len(colleges)} college entries, {len(m)} college-course rows,"
          f" {len(seats)} seat rows)")


# ------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--all", action="store_true", help="every professional course")
    ap.add_argument("--profs", help='codes or names, e.g. "A,E,M" or "Architecture,Dental"')
    ap.add_argument("--seats", action="store_true", help="also click View for seat tables (slow)")
    ap.add_argument("--limit", type=int, default=0, help="only first N colleges per course (test)")
    ap.add_argument("--delay", type=float, default=1.5)
    ap.add_argument("--headless", action="store_true")
    args = ap.parse_args()
    CACHE.mkdir(exist_ok=True)

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=args.headless)
        ctx = browser.new_context(viewport={"width": 1400, "height": 900})
        page = ctx.new_page()
        page.goto(URL, wait_until="networkidle")
        prof_list = real(get_opts(page, PROF))

        if args.all:
            chosen = prof_list
        elif args.profs:
            want = [w.strip().lower() for w in args.profs.split(",")]
            chosen = [o for o in prof_list if o["value"].lower() in want or o["text"].lower() in want]
        else:
            print("Professional courses:")
            for o in prof_list:
                print(f"  {o['value']}  {o['text']}")
            print('\nRun with --all, or --profs "A,E,M"')
            browser.close()
            return

        map_rows = []
        for o in chosen:
            map_rows += build_map(page, o["value"], o["text"], args)
        seats, errors = ([], [])
        if args.seats:
            seats, errors = build_seats(page, ctx, map_rows, args)
        browser.close()

    write_excel(map_rows, seats, errors, prof_list)


if __name__ == "__main__":
    main()
